using Microsoft.VisualStudio.TestTools.UnitTesting;
using Computershare;

namespace BuySellTests
{
    [TestClass]
    public class BuySellTest
    {
        [TestMethod]
        public void TestFindMinMaxMaxBeforeMin()
        {
            Program testProgram = new Program();
            testProgram.stockPrices = new float[] { 19.15f, 14.58f, 22.47f, 12.89f};
            float expectedMax = 22.47f;
            int expectedMaxIndex = 2;
            float expectedMin = 12.89f;
            int expectedMinIndex = 3;
            testProgram.findMinMax();
            Assert.AreEqual(expectedMax, testProgram.max);
            Assert.AreEqual(expectedMaxIndex, testProgram.maxIndex);
            Assert.AreEqual(expectedMin, testProgram.min);
            Assert.AreEqual(expectedMinIndex, testProgram.minIndex);
        }

        [TestMethod]
        public void TestFindMinMaxMinBeforeMax()
        {
            Program testProgram = new Program();
            testProgram.stockPrices = new float[] { 19.15f, 12.89f, 14.58f, 22.47f};
            float expectedMax = 22.47f;
            int expectedMaxIndex = 3;
            float expectedMin = 12.89f;
            int expectedMinIndex = 1;
            testProgram.findMinMax();
            Assert.AreEqual(expectedMax, testProgram.max);
            Assert.AreEqual(expectedMaxIndex, testProgram.maxIndex);
            Assert.AreEqual(expectedMin, testProgram.min);
            Assert.AreEqual(expectedMinIndex, testProgram.minIndex);
        }

        [TestMethod]
        public void TestFindMinBeforeMaxMaxInMiddle()
        {
            Program testProgram = new Program();
            testProgram.stockPrices = new float[] { 19.15f, 12.89f, 14.58f, 22.47f, 15.17f, 11.99f };
            testProgram.maxIndex = 3;
            float expectedMinBeforeMax = 12.89f;
            int expectedMinBeforeMaxIndex = 1;
            testProgram.findMinBeforeMax();
            Assert.AreEqual(expectedMinBeforeMax, testProgram.minBeforeMax);
            Assert.AreEqual(expectedMinBeforeMaxIndex, testProgram.minBeforeMaxIndex);
        }

        [TestMethod]
        public void TestFindMinBeforeMaxMaxFirst()
        {
            Program testProgram = new Program();
            testProgram.stockPrices = new float[] { 25.18f, 19.15f, 12.89f, 14.58f, 22.47f, 15.17f, 11.99f };
            testProgram.maxIndex = 0;
            float expectedMinBeforeMax = 25.18f;
            int expectedMinBeforeMaxIndex = 0;
            testProgram.findMinBeforeMax();
            Assert.AreEqual(expectedMinBeforeMax, testProgram.minBeforeMax);
            Assert.AreEqual(expectedMinBeforeMaxIndex, testProgram.minBeforeMaxIndex);
        }

        [TestMethod]
        public void TestFindMinBeforeMaxMaxSecond()
        {
            Program testProgram = new Program();
            testProgram.stockPrices = new float[] { 19.15f, 22.89f, 14.58f, 22.47f, 15.17f, 11.99f };
            testProgram.maxIndex = 1;
            float expectedMinBeforeMax = 19.15f;
            int expectedMinBeforeMaxIndex = 0;
            testProgram.findMinBeforeMax();
            Assert.AreEqual(expectedMinBeforeMax, testProgram.minBeforeMax);
            Assert.AreEqual(expectedMinBeforeMaxIndex, testProgram.minBeforeMaxIndex);
        }

        [TestMethod]
        public void TestFindMaxAfterMinMinInMiddle()
        {
            Program testProgram = new Program();
            testProgram.stockPrices = new float[] { 19.15f, 22.89f, 11.58f, 13.63f, 12.47f, 15.17f, 13.45f };
            testProgram.min = 11.58f;
            testProgram.minIndex = 2;
            float expectedMaxAfterMin = 15.17f;
            int expectedMaxAfterMinIndex = 5;
            testProgram.findMaxAfterMin();
            Assert.AreEqual(expectedMaxAfterMin, testProgram.maxAfterMin);
            Assert.AreEqual(expectedMaxAfterMinIndex, testProgram.maxAfterMinIndex);
        }

        [TestMethod]
        public void TestFindMaxAfterMinMinLast()
        {
            Program testProgram = new Program();
            testProgram.stockPrices = new float[] { 19.15f, 22.89f, 11.58f, 13.63f, 12.47f, 15.17f, 13.45f, 11.10f };
            testProgram.min = 11.10f;
            testProgram.minIndex = 7;
            float expectedMaxAfterMin = 11.10f;
            int expectedMaxAfterMinIndex = 7;
            testProgram.findMaxAfterMin();
            Assert.AreEqual(expectedMaxAfterMin, testProgram.maxAfterMin);
            Assert.AreEqual(expectedMaxAfterMinIndex, testProgram.maxAfterMinIndex);
        }

        [TestMethod]
        public void TestFindMaxAfterMinMinSecondLast()
        {
            Program testProgram = new Program();
            testProgram.stockPrices = new float[] { 19.15f, 22.89f, 11.58f, 13.63f, 12.47f, 15.17f, 13.45f, 11.10f, 12.15f };
            testProgram.min = 11.10f;
            testProgram.minIndex = 7;
            float expectedMaxAfterMin = 12.15f;
            int expectedMaxAfterMinIndex = 8;
            testProgram.findMaxAfterMin();
            Assert.AreEqual(expectedMaxAfterMin, testProgram.maxAfterMin);
            Assert.AreEqual(expectedMaxAfterMinIndex, testProgram.maxAfterMinIndex);
        }
    }
}
