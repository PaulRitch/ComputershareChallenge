﻿using System;
using System.IO;
using System.Linq;

namespace Computershare
{


    public class Program
    {
        private static string inputPath = "../../../ChallengeSampleDataSet1.txt";//location of the file being read
        public float max { get; set; }
        public int maxIndex { get; set; }
        public float min { get; set; }
        public int minIndex { get; set; }
        public float minBeforeMax { get; set; }
        public int minBeforeMaxIndex { get; set; }
        public float maxAfterMin { get; set; }
        public int maxAfterMinIndex { get; set; }
        public float[] stockPrices { get; set; }

        static void Main(string[] args)
        {
            Program program = new Program();
            program.readFromFile();
            program.findMinMax();
            if (program.minIndex < program.maxIndex) //check if the min is before the max if it is output result if it's not do more calculations
            {
                outPutResult(program.minIndex, program.min, program.maxIndex, program.max);
            }
            else
            {
                program.findMinBeforeMax();
                program.findMaxAfterMin();
                if ((program.max - program.minBeforeMax) > (program.maxAfterMin - program.min))
                {
                    outPutResult(program.minBeforeMaxIndex, program.minBeforeMax, program.maxIndex, program.max);
                }
                else
                {
                    outPutResult(program.minIndex, program.min, program.maxAfterMinIndex, program.maxAfterMin);
                }
            }
        }

        //reads all the text from the file and puts it into an array of floats
        public void readFromFile()
        {
            string input = File.ReadAllText(inputPath);
            string[] StockPriceStings = input.Split(",");
            stockPrices = Array.ConvertAll(StockPriceStings, float.Parse);
        }

        //finds the min and max and their indexs within stockPrices
        public void findMinMax()
        {
            max = stockPrices[0];
            maxIndex = 0;
            min = stockPrices[0];
            minIndex = 0;
            for (int i = 1; i < stockPrices.Length; i++) //find both in one loop for faster result
            {
                if (stockPrices[i] > max)
                {
                    max = stockPrices[i];
                    maxIndex = i;
                }
                if (stockPrices[i] < min)
                {
                    min = stockPrices[i];
                    minIndex = i;
                }
            }
        }

        //finds the minimum before the max's index
        public void findMinBeforeMax()
        {
            minBeforeMax = stockPrices[0];
            minBeforeMaxIndex = 0;
            for (int i = 1; i < maxIndex; i++) //for loop doesn't run if max is the first
            {
                if (stockPrices[i] < minBeforeMax)
                {
                    minBeforeMax = stockPrices[i];
                    minBeforeMaxIndex = i;
                }
            }
        }

        //finds the max after the min's index
        public void findMaxAfterMin()
        {
            if (minIndex == stockPrices.Length - 1)//if min is last stops out of bounds
            {
                maxAfterMin = min;
                maxAfterMinIndex = stockPrices.Length - 1;
            }
            else
            {
                maxAfterMin = stockPrices[minIndex + 1];
                maxAfterMinIndex = minIndex + 1;
                for (int i = minIndex + 2; i < stockPrices.Length; i++)
                {
                    if (stockPrices[i] > maxAfterMin)
                    {
                        maxAfterMin = stockPrices[i];
                        maxAfterMinIndex = i;
                    }
                }
            }
        }

        //outputs the result to the console
        public static void outPutResult(int minIndex, float min, int maxIndex, float max)
        {
            Console.WriteLine((minIndex + 1) + "(" + min + ")," + (maxIndex + 1) + "(" + max + ")");
        }
    }
}
